<?php 

class Person {
    public  function __construct()
    {
        echo 'Person Class';
    }
}