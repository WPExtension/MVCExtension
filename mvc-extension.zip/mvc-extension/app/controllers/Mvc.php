<?php 

use \PHPAutoloader\Classes\libraries\Controller;

class Mvc extends Controller {

   public function __construct() {

    

   }

}