<?php 

class Users {
    public function __construct()
    {
       
    }

    public function index() {
        echo ' Users Controllers!';
    }

    public function account() {
        echo 'User account';
    }
}